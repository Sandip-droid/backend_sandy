


//api for adding doctor




const addDoctor = async (req, res) => {

    try{


        const {name,email,password,image,speciality,degree,experience,about,fees,available,address,data} = req.body;

         

    }catch(err){

    }


}

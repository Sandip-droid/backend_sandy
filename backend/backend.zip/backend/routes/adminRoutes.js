const express = require('express');

const {addDoctor,adminLogin,AllDoctor} = require('../controllers/adminController.js')

const upload=require('../middlewares/multer.js');
const authAdmin = require('../middlewares/authAdmin.js');
const router=express.Router();


router.post('/add-doctor',authAdmin,upload.single('image'),addDoctor);
router.get('/doctorList',authAdmin,AllDoctor)
router.post('/login',adminLogin);



module.exports=router;